SPRINGER NATURE SNAPP LATEX SOURCE PACKAGE

MAIN LATEX FILE: main.tex
COMPILER: pdflatex

The archive contains exactly one LaTeX file with a document class and document
environment: main.tex. It builds the clean, unmarked manuscript.

For a manual build, run pdflatex twice:

  pdflatex -interaction=nonstopmode main.tex
  pdflatex -interaction=nonstopmode main.tex

The compiled bibliography (main.bbl) is supplied. The supplementary label map
(supplementary-labels.tex) is generated automatically from the current
standalone supplement. The manuscript continues to cite symbolic label names;
supplementary numbers are not entered manually. The generated TeX map avoids
depending on an auxiliary .aux file that an online compiler may discard.
