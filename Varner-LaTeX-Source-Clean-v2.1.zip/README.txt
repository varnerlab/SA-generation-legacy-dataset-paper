SPRINGER NATURE SNAPP LATEX SOURCE PACKAGE

MAIN LATEX FILE: main.tex
COMPILER: pdflatex

The archive contains exactly one LaTeX file with a document class and document
environment: main.tex. It builds the clean, unmarked manuscript.

For a manual build, run pdflatex twice:

  pdflatex -interaction=nonstopmode main.tex
  pdflatex -interaction=nonstopmode main.tex

The compiled bibliography (main.bbl) and the LaTeX-generated supplementary
label data (supplementary-information.aux) are supplied. Supplementary citation
numbers remain generated from the labels in the standalone supplement; they
are not entered manually in the manuscript source.
